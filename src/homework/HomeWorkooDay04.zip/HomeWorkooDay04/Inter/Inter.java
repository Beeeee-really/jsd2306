package homework.HomeWorkooDay04.Inter;

public interface Inter {

}
