package homework.HomeWorkooDay04.Inter;

public interface InterInter {
    void show();
}
