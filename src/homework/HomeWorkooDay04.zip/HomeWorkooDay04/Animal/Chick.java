package homework.HomeWorkooDay04.Animal;

public class Chick extends Animal {

    Chick(String name, int age, String color) {
        super(name, age, color);
    }

    public void eat() {

    }

    void layEggs() {

    }
}
