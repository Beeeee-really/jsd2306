package homework.HomeWorkooDay04.Animal;

public class Master {
    void feed(){

    }
}
