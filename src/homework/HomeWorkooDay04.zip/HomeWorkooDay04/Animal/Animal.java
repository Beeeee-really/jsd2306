package homework.HomeWorkooDay04.Animal;

public class Animal {
    String name;
    int age;
    String color;


    Animal(String name, int age, String color) {
        this.age = age;
        this.name = name;
        this.color = color;

    }

    void drink() {

    }

    void eat() {

    }


}
