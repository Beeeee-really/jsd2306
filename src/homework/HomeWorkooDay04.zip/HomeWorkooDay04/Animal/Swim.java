package homework.HomeWorkooDay04.Animal;

public interface Swim {
    void swim();
}
