package homework.HomeWork7.Animal;

import OOP.day02.Animal;

public class Fish extends Animal {
    Fish(String name, int age, String color, String type) {
        super(name, age, color, type);
    }
}
