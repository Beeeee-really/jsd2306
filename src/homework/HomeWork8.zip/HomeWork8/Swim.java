package homework.HomeWork8;

public interface Swim {
    void swim();
}
