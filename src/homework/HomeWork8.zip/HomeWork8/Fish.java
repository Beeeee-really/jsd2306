package homework.HomeWork8;

public class Fish extends Animal implements Swim{
    Fish (String name,int age,String color){
        super(name,age,color);
    }

    public void eat(){

    }
    public void swim(){

    }
}
