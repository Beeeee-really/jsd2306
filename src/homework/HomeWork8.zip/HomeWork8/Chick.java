package homework.HomeWork8;

public class Chick extends Animal{

    Chick (String name,int age,String color){
        super(name,age,color);
    }
    public void eat(){

    }

    void layEggs(){

    }

}
