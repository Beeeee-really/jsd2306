package homework.HomeWork8;

public class Dog extends Animal implements Swim{

    Dog (String name,int age,String color){
        super(name,age,color);
    }

    public void drink(){

    }

    public void swim(){

    }


    public void eat() {

    }

    void lookHome(){

    }


}
